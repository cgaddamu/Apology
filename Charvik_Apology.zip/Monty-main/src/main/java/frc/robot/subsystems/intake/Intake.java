package frc.robot.subsystems.intake;

import static frc.robot.Constants.IntakeConstants.*;

import com.ctre.phoenix.motorcontrol.ControlMode;
import com.ctre.phoenix.motorcontrol.can.TalonSRX;

import edu.wpi.first.wpilibj.PneumaticHub;
import edu.wpi.first.wpilibj.Solenoid;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;
import edu.wpi.first.wpilibj2.command.SubsystemBase;

public class Intake extends SubsystemBase {

  private final TalonSRX mainMotor;
  private final TalonSRX followerA;
  private final TalonSRX followerB;

  private final Solenoid actuator;

  public Intake(PneumaticHub hub) {

    mainMotor = new TalonSRX(frontRollerID);
    followerA = new TalonSRX(leftIndexerID);
    followerB = new TalonSRX(rightIndexerID);

    actuator = hub.makeSolenoid(feederSolenoid);

    initializeMotors();
    configureFollowers();

    actuator.set(false);
  }

  private void initializeMotors() {
    mainMotor.configFactoryDefault();
    followerA.configFactoryDefault();
    followerB.configFactoryDefault();
  }

  private void configureFollowers() {
    followerA.follow(mainMotor);
    followerB.follow(mainMotor);
  }

  public void setSpeed(double value) {

    double scaled = value * maxIntakeSpeed;

    SmartDashboard.putNumber("Intake Speed", scaled);

    mainMotor.set(ControlMode.PercentOutput, scaled);
  }

  public double getSpeed() {
    return mainMotor.getMotorOutputPercent();
  }

  public void setState(boolean open) {

    if (open) {
      SmartDashboard.putString("Intake State", "Open");
    } else {
      SmartDashboard.putString("Intake State", "Closed");
    }

    actuator.set(open);
  }

  public boolean getState() {
    return actuator.get();
  }
}